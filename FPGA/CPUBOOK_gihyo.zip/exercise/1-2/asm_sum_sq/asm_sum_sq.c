// asm_sum_sq.c
#include	<stdio.h>

void main(void) {					// cx : sum_sq
	short	sum_sq;					// ax : i
									// bx : j
	__asm {
				mov	 cx, 0			// sum_sq = 0;
				mov	 ax, 0			// i = 0;
		LOOP1:  inc  ax				// i = i + 1;
				mov  bx, 0			// j = 0;
		LOOP2:  inc  bx				// j = j + 1;
				add  cx, ax			// sum_sq = sum_sq + i;
				cmp  ax, bx
				jne  LOOP2			// if(i != j) goto LOOP2;
				cmp  ax, 20			// 
				jne  LOOP1			// if(i != 20) goto LOOP1;
				mov  sum_sq, cx
	}
	printf("sum_sq = %d\n", sum_sq);
}