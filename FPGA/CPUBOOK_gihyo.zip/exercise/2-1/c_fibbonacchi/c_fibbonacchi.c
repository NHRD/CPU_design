// c_fibbonacchi.c
#include	<stdio.h>

void main(void) {
	int		n;
	short	fib[100];

	fib[1] = 1;
	fib[2] = 1;

	for (n = 3; n <= 20; n++) {
		fib[n] = fib[n - 1] + fib[n - 2];
		printf("n = %d, fib[n] = %d\n", n, fib[n]);
	}
}
