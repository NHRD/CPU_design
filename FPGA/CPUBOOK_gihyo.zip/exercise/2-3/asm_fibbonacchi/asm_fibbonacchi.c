// asm_fibbonacchi.c
#include	<stdio.h>

void main(void) {
	short	fib;

	__asm {
		mov  ax, 1		// fib_last = 1
		mov	 bx, 1		// fib_now = 1
		mov  cx, 3		// n = 3
LOOP1:  add  ax, bx		// fib_n = fin_now + fib_last
		cmp  cx, 20		//
		je   MOUT		// if(n==20) goto MOUT
		mov  dx, ax		// tmp = fib_n
		mov  ax, bx		// fib_last = fib_now
		mov  bx, dx		// fib_now = tmp  (fib_n)
		inc  cx			// n = n + 1
		jmp  LOOP1		// goto LOOP1
MOUT:   mov  fib, ax
	}
	printf("fib(20) = %d\n", fib);
}
